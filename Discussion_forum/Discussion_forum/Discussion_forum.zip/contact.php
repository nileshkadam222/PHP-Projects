<?php  require("header.php"); ?>
<script type="text/javascript">
	document.getElementById("acontact").className="active";
</script>


	<h1>Contact Us</h1>
    <table>
    
	
    <tr><td rowspan="4"><img src="ups/satish.jpg" style='height:100px; width:100px';></td><td>Name</td><td>:</td><td>techstudypro</td></tr>
    <tr><td rowspan="1">Contact No</td><td>:</td><td>9594197606</td></tr>
    <tr><td rowspan="1">E-Mail Add</td><td>:</td><td>nilesh.kadam222@gmail.com</td></tr>
   <tr><td rowspan="1">Website</td><td>:</td><td><a href="#">www.techstudypro.in</a></td></tr>
    </table>
    
<?php require("footer.php"); ?>